Thanks for visiting MaterialDesignIcons.com
Check back often for new icons and follow @MaterialIcons for updates.

Icon: map-marker
By: Google